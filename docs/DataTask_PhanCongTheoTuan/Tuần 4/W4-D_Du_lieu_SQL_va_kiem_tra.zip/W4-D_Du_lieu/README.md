# W4-D Bộ dữ liệu mẫu và Chương 4

Phiên bản ngày 09/11/2026, đồng bộ W4-A/B và W4-C hoàn thiện sau review.

## Nội dung

- `seed.json`: toàn bộ 60 dòng, 19 bảng, 450 giá trị; số tiền thập phân lưu chuỗi để giữ chính xác khi trao đổi.
- `schema_ref.json`: 132 định nghĩa cột, NULL, DEFAULT, PK/UK/FK kế thừa W4-B.
- `constraint_ref.json`: danh mục W4-C gồm 38 CHECK nghiệp vụ và phạm vi các họ MID/TXT/TEL.
- `00_Khoi_tao_va_nap_mau.sql`: tạo 19 bảng, 19 PK, 15 UQ, 2 unique filtered index, 120 CHECK (38 + 35 MID + 44 TXT + 3 TEL), 7 DEFAULT; thêm 24 FK trước seed, thêm FK01 WITH CHECK sau seed; đối soát 293 truy vấn và metadata trước commit.
- `01_Doi_soat_sau_nap.sql`: 293 truy vấn đối soát chỉ đọc và bảng tiền hóa đơn; dòng Violations phải bằng 0 trên đúng bộ seed.
- `reconciliation_ref.json`: ID và nội dung 293 truy vấn; đầu vào cho mô hình kiểm tra.
- `kiem_tra_tinh.py`: kiểm tra tái lập chỉ dùng thư viện chuẩn Python 3; chuyển các biểu thức sang mô hình SQLite, đồng thời kiểm tra kiểu/khóa/FK và tiền Decimal bằng Python.
- `ket_qua_kiem_tra.json`: kết quả thực tế, nhóm phép kiểm tra, 12 bản sao sai, phiên bản môi trường và SHA-256.
- `danh_sach_kiem_tra.csv`: 1.405 ID kiểm tra tĩnh và actual/expected. Không phải 1.405 ca TC độc lập.

## Kiểm tra tĩnh

Giải nén toàn bộ thư mục và chạy tại đó:

```sh
python3 kiem_tra_tinh.py
```

Chương trình tạo lại hai tệp kết quả JSON/CSV. Kỳ vọng trên bộ dữ liệu này: 1.405 phép đạt, 0 lỗi; phát hiện cả 12 bản sao sai. Đây là kiểm tra dữ liệu và mô hình truy vấn, KHÔNG thực thi T-SQL trên SQL Server; khác biệt collation/locking/trigger/transaction native chưa được chứng minh. Không dùng số 665 của bản D cũ vì không có đầu vào kiểm chứng số đó.

## Nạp SQL Server để W4-E kiểm chứng

1. Người thực hiện tự chuẩn bị và chọn một CSDL kiểm thử riêng, trống, trên SQL Server đã được nhóm chọn. Kiểm tra đúng tên CSDL trước khi chạy; script không tự CREATE DATABASE hay USE.
2. Mở tệp `00_Khoi_tao_va_nap_mau.sql` bằng UTF-8 trong SSMS; chạy TOÀN BỘ một lần bằng tài khoản có quyền tạo bảng/constraint/index và lấy application lock. Script từ chối nếu đã có bất kỳ bảng đích nào. Không sửa guard để nạp đè; dùng CSDL kiểm thử mới khi muốn chạy lại.
3. Script tạo DDL và seed trong một transaction, lấy khóa `BV_W4C_WRITE`, chưa tạo FK01 cho đến khi nạp xong vòng KHOA–NHAN_VIEN–BAC_SI. FK01 là nhánh ADD mới, không phải CHECK lại một constraint chưa tồn tại. Sai đối soát hoặc lỗi thực thi: rollback; giữ nguyên thông báo lỗi để sửa.
4. Chỉ khi có thông báo commit thực tế mới chạy `01_Doi_soat_sau_nap.sql`, lưu kết quả 19 row-count, 25 FK và các đối soát khác, cùng metadata FK/CHECK bật và được trust. Tất cả Violations kỳ vọng bằng 0, hóa đơn giống trong Word/PDF.
5. Ghi DBMS/phiên bản, database, hash file, thời gian, kết quả và lỗi thực tế vào W4-E. Tác giả chưa chạy SQL Server và chưa thực thi TC01–TC12.

Script 00 chỉ là bootstrap trong cửa sổ khởi tạo độc quyền; không phải bộ procedure vận hành G01. Các kiểm tra C01–C10 chỉ kiểm tra trạng thái seed cuối. Cấm diễn giải kết quả seed thành bằng chứng tự động ngăn UPDATE/DELETE hay hai phiên đồng thời. Trước khi mở ghi ứng dụng, phải triển khai các procedure, kiểm tra chuyển trạng thái/giá lịch sử và chính sách quyền ghi của W4-C; kiểm thử ở W4-E. Không có script xóa/nạp lại hay thay đổi dữ liệu sản xuất trong gói này.

## Quy ước dữ liệu

Mọi họ tên, mã giấy tờ, chứng chỉ, số điện thoại, địa chỉ, thuốc, chỉ định, chẩn đoán và kết quả đều là mô phỏng. `DEMO_...`, số liên hệ bắt đầu 000 và email `example.invalid` là giá trị minh họa. Các mô tả liều/cách dùng không phải hướng dẫn điều trị.

Mốc snapshot là `2026-11-01 12:00:00.000`, giờ Asia/Ho_Chi_Minh. Trạng thái giường là tại mốc đó. Ngày dự kiến xuất viện không thay ngày xuất thực tế. Tồn thuốc là số dư mô phỏng, không có sổ kho để chứng minh các giao dịch nhập/xuất trước đó. Giá danh mục hiện tại được giả định đã thay sau giá chụp; schema chưa có lịch sử hiệu lực giá để chứng minh thời điểm thay.

Ba hóa đơn minh họa chỉ gồm thuốc + dịch vụ: 152.000, 224.000, 146.000 VND; số BHYT chốt mô phỏng 80.000, 0, 100.000 VND; BN trả dẫn xuất 72.000, 224.000, 46.000 VND. Không tính thêm tiền giường; không suy chi trả BHYT bằng tỷ lệ thẻ.

P01–P08 của W4-A/B/C vẫn phải được nhóm xử lý: lịch sử thẻ, kỹ thuật viên/phiếu xét nghiệm, đợt điều trị và tiền giường, thuộc tính còn thiếu, khóa cần review, cưỡng chế vận hành và đồng bộ báo cáo. Seed tuân mốc 19 bảng không tự giải quyết các vấn đề đó.

## Nguồn

Sheet Phân công chi tiết B21:L21; W4-A; W4-B; W4-C bản hoàn thiện 29 trang ngày 09/11/2026; bản W4-D cũ 5 trang; Review_W4-C_W4-D_Thuy 10 trang. Quy tắc gốc W3 và báo cáo bệnh viện được kế thừa theo đối chiếu trong A/B/C.

Tham chiếu cú pháp:
https://learn.microsoft.com/en-us/sql/t-sql/statements/create-index-transact-sql
https://learn.microsoft.com/en-us/sql/relational-databases/tables/disable-foreign-key-constraints-with-insert-and-update-statements
https://learn.microsoft.com/en-us/sql/t-sql/functions/cast-and-convert-transact-sql
