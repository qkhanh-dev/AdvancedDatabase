"""Reproducible static checks for the W4-D synthetic dataset.
Python standard library only. This is NOT a SQL Server execution harness.
Run: python3 kiem_tra_tinh.py
"""
from pathlib import Path
from decimal import Decimal, InvalidOperation
from datetime import datetime, date, timezone
from collections import Counter
import json, re, sqlite3, hashlib, csv, copy, sys

ROOT=Path(__file__).resolve().parent
def read(name):return json.loads((ROOT/name).read_text(encoding='utf-8-sig'))
SCHEMA=read('schema_ref.json'); CONSTRAINTS=read('constraint_ref.json')
QUERIES=read('reconciliation_ref.json')
EXPECTED_COUNTS=dict(zip(SCHEMA,[2,4,3,6,2,2,2,4,3,2,4,3,3,4,3,3,3,3,4]))
EXPECTED_DEFAULTS=[['BAC_SI','PhuCapKham','0'],['DIEU_DUONG','PhuCapTruc','0'],['BENH_NHAN','GioiTinh','CHUA_RO'],['DON_THUOC','TrangThaiPhatThuoc','CHUA_PHAT'],['THUOC','SoLuongTon','0'],['HOA_DON','TrangThaiTT','CHUA_THANH_TOAN'],['LICH_TRUC','TrangThaiDiemDanh','CHUA_DIEM_DANH']]

def valid_type(v,typ):
 if v is None:return True
 try:
  if typ.startswith(('VARCHAR','NVARCHAR')):
   if not isinstance(v,str):return False
   m=re.search(r'\((\d+)\)',typ)
   length=len(v.encode('utf-16-le'))//2 if typ.startswith('NVARCHAR') else len(v.encode('ascii'))
   return not m or length<=int(m[1])
  if typ=='DATE':return isinstance(v,str) and date.fromisoformat(v).isoformat()==v
  if typ.startswith('DATETIME2'):
   return isinstance(v,str) and datetime.strptime(v,'%Y-%m-%d %H:%M:%S.%f').strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]==v
  if typ.startswith('DECIMAL'):
   if not isinstance(v,(str,int)) or isinstance(v,bool):return False
   p,s=map(int,re.findall(r'\d+',typ));d=Decimal(v)
   return d.is_finite() and d==d.quantize(Decimal(1).scaleb(-s)) and abs(d)<Decimal(10)**(p-s)
  if typ in ('BIT','INT','SMALLINT'):
   if type(v) is not int:return False
   lo,hi={'BIT':(0,1),'INT':(-2147483648,2147483647),'SMALLINT':(-32768,32767)}[typ]
   return lo<=v<=hi
 except (ValueError,TypeError,UnicodeError,InvalidOperation):return False
 return False

def translated_sql(sql):
 sql=sql.replace('dbo.','').replace('COUNT_BIG','COUNT')
 sql=re.sub(r"\bN'","'",sql)
 sql=sql.replace('CAST(ThoiGianKham AS DATE)','date(ThoiGianKham)')
 sql=re.sub(r'CAST\(@Snapshot AS date\)','date(@Snapshot)',sql,flags=re.I)
 sql=re.sub(r'LEFT\((\[[^]]+\]),1\)',r'substr(\1,1,1)',sql)
 # SQLite LIKE does not use SQL Server bracket classes. Equivalent ASCII
 # domain expressions replace the two NOT LIKE patterns for this harness.
 sql=re.sub(r"(\[[^]]+\]) COLLATE Latin1_General_100_BIN2 NOT LIKE '%\[\^A-Z0-9_-\]%'",r"MID_OK(\1)=1",sql)
 sql=re.sub(r"(\[[^]]+\]) COLLATE Latin1_General_100_BIN2 NOT LIKE '%\[\^0-9+\]%'",r"PHONE_CHARS_OK(\1)=1",sql)
 return sql

def validate(seed):
 D=seed['tables']; checks=[]
 def check(id,group,actual,expected):
  checks.append({'id':id,'group':group,'passed':actual==expected,'actual':actual,'expected':expected})
 check('SCHEMA_TABLES','schema',list(D),list(SCHEMA))
 check('SCHEMA_COLUMNS','schema',sum(len(t['rows']) for t in SCHEMA.values()),132)
 check('SCHEMA_NN','schema',sum(r[2]=='Không' for t in SCHEMA.values() for r in t['rows']),96)
 check('SCHEMA_DEFAULTS','schema',[[n,r[0],r[3]] for n,t in SCHEMA.items() for r in t['rows'] if r[3]!='—'],EXPECTED_DEFAULTS)
 check('ROW_TOTAL','row_counts',sum(len(v) for v in D.values()),60)
 for n,t in SCHEMA.items():
  values=D.get(n,[]);fields=[r[0] for r in t['rows']]
  check('COUNT_'+n,'row_counts',len(values),EXPECTED_COUNTS[n])
  for i,v in enumerate(values,1):
   check(f'FIELDS_{n}_{i}','fields',list(v),fields)
   for c,typ,nullable,df,desc in t['rows']:
    x=v.get(c);key=f'{n}_{i}_{c}'
    check('NULL_'+key,'nullability',x is not None or nullable=='Có',True)
    check('TYPE_'+key,'types',valid_type(x,typ),True)
  keys=[tuple(v.get(c) for c in t['pk']) for v in values]
  check('PK_'+n,'keys',len(keys),len(set(keys)))
  for i,u in enumerate(t['uk'],1):
   # The two optional BN unique columns ignore NULL, matching filtered UX.
   keys=[tuple(v.get(c) for c in u) for v in values if all(v.get(c) is not None for c in u)]
   check(f'UK_{n}_{i}','keys',len(keys),len(set(keys)))
  for c,dest in t['fks'].items():
   tn,tc=dest.split('.');allowed={v.get(tc) for v in D.get(tn,[])}
   for i,v in enumerate(values,1):check(f'FK_{n}_{i}_{c}','references',v.get(c) is None or v[c] in allowed,True)
 # SQL expression evaluation is a port to SQLite, not SQL Server behavior.
 db=sqlite3.connect(':memory:')
 db.create_function('LEN',1,lambda x:None if x is None else len(str(x).rstrip(' ')))
 db.create_function('DATALENGTH',1,lambda x:None if x is None else len(str(x).encode('utf-8')))
 db.create_function('NCHAR',1,chr)
 db.create_function('CHARINDEX',3,lambda needle,x,start:None if x is None else str(x).find(needle,start-1)+1)
 db.create_function('MID_OK',1,lambda x:None if x is None else int(bool(re.fullmatch(r'[A-Z0-9_-]+',x))))
 db.create_function('PHONE_CHARS_OK',1,lambda x:None if x is None else int(bool(re.fullmatch(r'[0-9+]+',x))))
 for n,t in SCHEMA.items():
  fields=[r[0] for r in t['rows']]
  cols=[f'[{r[0]}] '+('NUMERIC' if r[1].startswith(('DECIMAL','INT','SMALLINT','BIT')) else 'TEXT') for r in t['rows']]
  db.execute('CREATE TABLE ['+n+'] ('+','.join(cols)+')')
  db.executemany('INSERT INTO ['+n+'] VALUES ('+','.join('?' for c in fields)+')',[[v.get(c) for c in fields] for v in D.get(n,[])])
 for q in QUERIES:
  group='domains' if q['id'].startswith('CK') else ('business' if q['id'].startswith(('C0','C10','BIRTH','DATA')) else 'query_reconciliation')
  try:
   found=db.execute(translated_sql(q['sql']),{'Snapshot':seed['snapshot']}).fetchone()[0]
   check('SQLMODEL_'+q['id'],group,found,0)
  except sqlite3.Error as exc:check('SQLMODEL_'+q['id'],group,'ERROR '+str(exc),0)
 db.close()
 # Recompute money using Decimal independently of the SQL model.
 expected={'HD01':('42000.00','110000.00','152000.00','80000.00','72000.00'),'HD02':('24000.00','200000.00','224000.00','0.00','224000.00'),'HD03':('36000.00','110000.00','146000.00','100000.00','46000.00')}
 invoices=[]
 for h in D.get('HOA_DON',[]):
  dons={v['MaDon'] for v in D['DON_THUOC'] if v['MaLuotKham']==h['MaLuotKham']}
  drug=sum((Decimal(v['SoLuong'])*Decimal(v['DonGiaBan']) for v in D['CT_DON_THUOC'] if v['MaDon'] in dons),Decimal(0))
  svc=sum((Decimal(v['SoLuong'])*Decimal(v['DonGiaDV']) for v in D['SU_DUNG_DV'] if v['MaLuotKham']==h['MaLuotKham']),Decimal(0))
  gross=Decimal(h['TongTienGoc']);bhyt=Decimal(h['TienBHYTChiTra'])
  got=tuple(f'{x:.2f}' for x in [drug,svc,gross,bhyt,gross-bhyt])
  check('MONEY_'+h['MaHD'],'invoice',got,expected.get(h['MaHD']))
  check('MONEY_SUM_'+h['MaHD'],'invoice',f'{drug+svc:.2f}',f'{gross:.2f}')
  invoices.append({'invoice':h['MaHD'],'visit':h['MaLuotKham'],'drug':got[0],'service':got[1],'gross':got[2],'insurance':got[3],'patient':got[4]})
 smoke=[('Q01',len(D['BENH_NHAN']),4),('Q02',len(D['NHAN_VIEN']),6),('Q03',sum(v['NgayKetThuc'] is None for v in D['PHAN_GIUONG']),2),('Q04',next((f"{Decimal(v['TongTienGoc'])-Decimal(v['TienBHYTChiTra']):.2f}" for v in D['HOA_DON'] if v['MaHD']=='HD01'),None),'72000.00'),('Q05',sum(v['TrangThaiPhatThuoc']=='DA_PHAT' for v in D['DON_THUOC']),2),('Q06',sum(v['KetQuaCLS'] is not None and v['MaKTVThucHien'] is None for v in D['SU_DUNG_DV']),0)]
 for id,a,b in smoke:check(id,'smoke',a,b)
 return checks,invoices

def main():
 seed=read('seed.json');checks,invoices=validate(seed)
 # Intentionally incorrect copies demonstrate selected validator branches.
 mutations=[
  ('MUT01','PHONG',0,'MaKhoa','MISSING','references'),
  ('MUT02','KHOA',1,'MaKhoa','K01','keys'),
  ('MUT03','PHONG',0,'MaPhong',None,'nullability'),
  ('MUT04','NHAN_VIEN',1,'SoDienThoai','0000000101','keys'),
  ('MUT05','BENH_NHAN',0,'NhomMau','X','domains'),
  ('MUT06','BENH_NHAN',1,'MucHuongBHYT','80.00','domains'),
  ('MUT07','NHAN_VIEN',0,'LoaiNV','DIEU_DUONG','business'),
  ('MUT08','PHAN_GIUONG',1,'NgayBatDau','2026-11-01 10:00:00.000','business'),
  ('MUT09','PHONG',1,'LoaiPhong','KHAM','business'),
  ('MUT10','HOA_DON',0,'TongTienGoc','153000.00','invoice'),
  ('MUT11','PHONG',1,'SucChuaToiDa',1,'business'),
  ('MUT12','CT_DON_THUOC',0,'SoLuong',0,'domains')]
 mresults=[]
 for id,n,i,c,value,group in mutations:
  altered=copy.deepcopy(seed);altered['tables'][n][i][c]=value
  log,_=validate(altered);fail=[x for x in log if not x['passed']]
  detected=any(x['group']==group for x in fail)
  mresults.append({'id':id,'table':n,'row':i+1,'column':c,'wrong_value':value,'expected_group':group,'detected':detected,'failed_ids':[x['id'] for x in fail]})
 groups=[]
 for g in sorted({x['group'] for x in checks}):
  subset=[x for x in checks if x['group']==g];groups.append({'group':g,'checks':len(subset),'passed':sum(x['passed'] for x in subset),'failed':sum(not x['passed'] for x in subset)})
 report={'dataset':seed['version'],'snapshot':seed['snapshot'],'executed_at_utc':datetime.now(timezone.utc).isoformat(),'environment':{'python':sys.version.split()[0],'sqlite':sqlite3.sqlite_version},'method':'Python static validation and translated SQLite expression/query models. No SQL Server execution. No production mutation or concurrency tests.', 'tables':len(seed['tables']),'rows':sum(map(len,seed['tables'].values())),'values':sum(len(v) for vs in seed['tables'].values() for v in vs),'checks':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'groups':groups,'invoices':invoices,'mutations':mresults,'sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['seed.json','schema_ref.json','constraint_ref.json','reconciliation_ref.json','kiem_tra_tinh.py','00_Khoi_tao_va_nap_mau.sql','01_Doi_soat_sau_nap.sql']},'failures':[x for x in checks if not x['passed']]}
 (ROOT/'ket_qua_kiem_tra.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 with (ROOT/'danh_sach_kiem_tra.csv').open('w',newline='',encoding='utf-8-sig') as f:
  writer=csv.DictWriter(f,fieldnames=['id','group','passed','actual','expected']);writer.writeheader();writer.writerows(checks)
 print(json.dumps({'checks':report['checks'],'passed':report['passed'],'failed':report['failed'],'mutations_detected':sum(v['detected'] for v in mresults),'mutations_total':len(mresults),'failures':report['failures'][:5]},ensure_ascii=False))
 return 0 if report['failed']==0 and all(v['detected'] for v in mresults) else 1
if __name__=='__main__':raise SystemExit(main())
